## segway 2.0.1.dev0 run 0a27a970665b11e7a2b2989096b2d04e at 2017-07-11 13:04:45.670066

cd "/scratch/segway/test/simplevalidationcoords/test-20170711.185kKM"
"/scratch/software/bin/segway" "--num-labels=4" "--max-train-rounds=2" "--include-coords=../include-coords.bed" "--minibatch-fraction=0.1" "--split-sequences=25000" "--validation-coords=../validation-coords.bed" "--cluster-opt=" "train" "../test.genomedata" "traindir"
