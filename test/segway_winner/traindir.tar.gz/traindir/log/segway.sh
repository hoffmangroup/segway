## segway 1.2.0.dev-r7828 run dd8b7b267ab511e1a6d3000c2997d6ab at 2012-03-30 15:15:32.285534

cd "/net/noble/vol1/home/epaul9/projects/encode/src/2012/segway/test/segway_winner"
"/net/noble/vol1/home/epaul9/arch/Linux/RHEL6/x86_64/bin/segway" "--cluster-opt=-l rhel=6,testing=TRUE" "--include-coords=include-coords.bed" "--tracks-from=tracks.txt" "--num-labels=4" "--num-instances=10" "train" "simpleseg.genomedata" "traindir"
